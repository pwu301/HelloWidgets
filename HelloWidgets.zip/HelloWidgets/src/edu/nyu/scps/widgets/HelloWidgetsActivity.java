package edu.nyu.scps.widgets;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.Toast;
import android.widget.ToggleButton;

public class HelloWidgetsActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new OnClickListener() {
        	public void onClick(View V) {
        		Toast.makeText(HelloWidgetsActivity.this,"An Android button", Toast.LENGTH_SHORT).show();
        	}
        });
        
        final ToggleButton togglebutton = (ToggleButton) findViewById(R.id.togglebutton);
        togglebutton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Perform action on clicks
                if (togglebutton.isChecked()) {
                    Toast.makeText(HelloWidgetsActivity.this, "Checked", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(HelloWidgetsActivity.this, "Not checked", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        final RadioButton radio_red = (RadioButton) findViewById(R.id.radio_red);
        final RadioButton radio_blue = (RadioButton) findViewById(R.id.radio_blue);
        radio_red.setOnClickListener(radio_listener);
        radio_blue.setOnClickListener(radio_listener);
        
        final RatingBar ratingbar = (RatingBar) findViewById(R.id.ratingbar);
        ratingbar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Toast.makeText(HelloWidgetsActivity.this, "New Rating: " + rating, Toast.LENGTH_SHORT).show();
            }
        });
        
		final Handler handler1 = new Handler() {
			public void handleMessage(Message message) {
				ratingbar.setRating(1);
			}
		};
		

		final Handler handler2 = new Handler() {
			public void handleMessage(Message message) {
				ratingbar.setRating(2);
			}
		};
	    
		final Handler handler3 = new Handler() {
			public void handleMessage(Message message) {
				ratingbar.setRating(3);
			}
		};
		

		final Handler handler4 = new Handler() {
			public void handleMessage(Message message) {
				ratingbar.setRating(4);
			}
		};
		
		final Handler handler5 = new Handler() {
			public void handleMessage(Message message) {
				ratingbar.setRating(5);
			}
		};
		
		final MyThread myThread1 = new MyThread(handler1);
		final MyThread myThread2 = new MyThread(handler2);
		final MyThread myThread3 = new MyThread(handler3);
		final MyThread myThread4 = new MyThread(handler4);
		final MyThread myThread5 = new MyThread(handler5);
		myThread1.start();
        myThread2.start();
        myThread3.start();
        myThread4.start();
        myThread5.start();

       
       
    }
    
    private OnClickListener radio_listener = new OnClickListener() {
        public void onClick(View v) {
            // Perform action on clicks
            RadioButton rb = (RadioButton) v;
            Toast.makeText(HelloWidgetsActivity.this, rb.getText(), Toast.LENGTH_SHORT).show();
        }
    };
}


final class MyThread extends Thread {
	Handler handler;

	MyThread(Handler h) {
		handler = h;
	}
   
	public void run() {
		for (;;) {
			try {
				//1000 milliseconds == 1 second
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}

			final Message message = handler.obtainMessage(); //Get an empty Message.	
			
			handler.sendMessage(message);	//Calls handleMessage, below.
		}
	}
}